
Thanks for trying out SCORM Driver, free for non-commercial use!

To get started with SCORM Driver, you'll want to check out the Quickstart Guide here:
http://scorm.com/driverquickstart

Don't forget to read LICENSE.txt in this download to clarify what constitutes "free non-commercial use" of SCORM Driver.

To learn more about SCORM Driver (overview, technical docs, and pricing) visit the SCORM Driver section on our site:
http://scorm.com/scorm-solved/scorm-driver/

Thanks,
Rustici Software
info@scorm.com
(866.497.2676)
